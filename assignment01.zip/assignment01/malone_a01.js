console.log("Hello!");
console.log("My name is Jerry Malone!");
console.log("I am a student at Metropolitan Community College in Omaha, Nebraska!");
console.log("I am currently studying computer programming and my goal is to learn JavaScript.");
console.log("Thank you!");
console.log("");
console.log("Jerry Malone");
